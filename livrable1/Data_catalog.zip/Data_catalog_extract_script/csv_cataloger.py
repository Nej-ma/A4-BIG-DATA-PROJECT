
#!/usr/bin/env python3
"""
Recursively scan a source folder for CSV files, read their column headers,
and export an Excel report listing:
  - File name
  - Columns present
  - Relative path from the source folder

Comments and logs are intentionally in English, as requested.
"""
import argparse
import logging
import os
from pathlib import Path
from typing import List, Dict, Optional

import pandas as pd


def setup_logging(verbosity: int) -> None:
    """Configure root logger based on verbosity level."""
    level = logging.WARNING  # default
    if verbosity == 1:
        level = logging.INFO
    elif verbosity >= 2:
        level = logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def try_read_columns(csv_path: Path, encodings: List[str]) -> Optional[List[str]]:
    """Attempt to read only the header (column names) of a CSV with multiple encodings.

    Returns list of column names on success, or None on failure.
    """
    # We only need the header row; using nrows=0 is fast and memory-efficient.
    read_kwargs = dict(
        nrows=0,
        # sep=None + engine='python' will attempt to sniff delimiter
        sep=None,
        engine='python',
    )
    last_err = None
    for enc in [None] + encodings:
        try:
            logging.debug("Trying to read header with encoding=%s", enc or "default")
            df = pd.read_csv(csv_path, encoding=enc, **read_kwargs)  # type: ignore[arg-type]
            return list(df.columns.astype(str))
        except Exception as e:
            last_err = e
            logging.debug("Failed with encoding=%s: %s", enc or "default", e)
            continue
    logging.warning("Could not read columns for %s. Last error: %s", csv_path, last_err)
    return None


def collect_csv_metadata(root: Path, encodings: List[str]) -> List[Dict[str, str]]:
    """Walk the directory tree and gather metadata for each CSV file."""
    results: List[Dict[str, str]] = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            # Match .csv case-insensitively
            if not name.lower().endswith('.csv'):
                continue
            full_path = Path(dirpath) / name
            rel_path = str(full_path.relative_to(root)).replace(os.sep, '/')
            logging.info("Processing %s", rel_path)

            cols = try_read_columns(full_path, encodings)
            cols_str = "; ".join(cols) if cols is not None else ""

            results.append({
                "file_name": name,
                "columns": cols_str,
                "relative_path": rel_path,
            })
    return results


def write_excel_report(rows: List[Dict[str, str]], output_path: Path) -> None:
    """Write the metadata rows to an Excel file."""
    df = pd.DataFrame(rows, columns=["file_name", "columns", "relative_path"])
    # Create parent directory if missing
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Use openpyxl engine implicitly if available
    df.to_excel(output_path, index=False)
    logging.info("Excel report written to %s", output_path)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Scan a folder recursively to list CSV files and their columns, then export to Excel."
    )
    p.add_argument("source", type=Path, help="Source folder to scan (root).")
    p.add_argument(
        "-o", "--output",
        type=Path,
        default=Path("csv_catalog.xlsx"),
        help="Output Excel file path (default: ./csv_catalog.xlsx)"
    )
    p.add_argument(
        "-v", "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v for INFO, -vv for DEBUG)."
    )
    p.add_argument(
        "--encodings",
        nargs="+",
        default=["utf-8-sig", "cp1252", "latin1"],
        help="Extra encodings to try if UTF-8 fails (default: %(default)s)."
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    setup_logging(args.verbose)

    source: Path = args.source
    if not source.exists() or not source.is_dir():
        logging.error("Source path does not exist or is not a directory: %s", source)
        raise SystemExit(1)

    logging.info("Starting scan in: %s", source.resolve())
    rows = collect_csv_metadata(source, args.encodings)

    # Sort results by relative path for a consistent output
    rows.sort(key=lambda r: (r["relative_path"].lower(), r["file_name"].lower()))

    write_excel_report(rows, args.output)
    logging.info("Done. %d CSV file(s) processed.", len(rows))


if __name__ == "__main__":
    main()
