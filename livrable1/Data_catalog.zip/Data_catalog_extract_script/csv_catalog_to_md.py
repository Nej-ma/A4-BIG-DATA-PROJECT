
#!/usr/bin/env python3
"""
Convert the Excel output of csv_cataloger.py into a Markdown (.md) report.

The Excel is expected to contain the columns:
  - file_name
  - columns  (semicolon-separated string)
  - relative_path

Comments and logs are in English (per request).
"""
import argparse
import logging
from pathlib import Path
from datetime import datetime
from typing import List

import pandas as pd


def setup_logging(verbosity: int) -> None:
    level = logging.WARNING  # default
    if verbosity == 1:
        level = logging.INFO
    elif verbosity >= 2:
        level = logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def split_columns(col_str: str) -> List[str]:
    """Split the semicolon-delimited columns string into a clean list."""
    if not isinstance(col_str, str) or not col_str.strip():
        return []
    # Split by ';' and strip whitespace around each part
    parts = [c.strip() for c in col_str.split(';')]
    # Remove empties and deduplicate while keeping order
    seen = set()
    result: List[str] = []
    for p in parts:
        if p and p not in seen:
            seen.add(p)
            result.append(p)
    return result


def dataframe_to_markdown(df: pd.DataFrame, include_table: bool = True, include_details: bool = True) -> str:
    """Render a Markdown string from the catalog DataFrame."""
    required_cols = {"file_name", "columns", "relative_path"}
    if not required_cols.issubset(df.columns):
        missing = required_cols - set(df.columns)
        raise ValueError(f"Input Excel is missing required columns: {missing}")

    # Normalize types
    df = df.copy()
    for col in ["file_name", "columns", "relative_path"]:
        df[col] = df[col].astype(str)

    # Sort by relative path then file name for consistency
    df.sort_values(by=["relative_path", "file_name"], key=lambda s: s.str.lower(), inplace=True)

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = []
    lines.append("# CSV Catalog Report")
    lines.append("")
    lines.append(f"_Generated on: {now}_")
    lines.append("")
    lines.append(f"Total CSV files: **{len(df)}**")
    lines.append("")

    if include_table:
        # Overview table: File | Relative Path | Columns Count
        lines.append("## Overview")
        lines.append("")
        lines.append("| File | Relative Path | Columns Count |")
        lines.append("|---|---|---:|")
        for _, row in df.iterrows():
            cols_list = split_columns(row["columns"])
            lines.append(f"| {row['file_name']} | `{row['relative_path']}` | {len(cols_list)} |")
        lines.append("")

    if include_details:
        lines.append("## Details")
        lines.append("")
        for _, row in df.iterrows():
            cols_list = split_columns(row["columns"])
            title = f"### {row['file_name']}"
            sub = f"`{row['relative_path']}`"
            lines.append(title)
            lines.append("")
            lines.append(f"**Relative path:** {sub}")
            lines.append("")
            if cols_list:
                lines.append("**Columns:**")
                for c in cols_list:
                    # Escape pipe characters to avoid table confusion if pasted
                    c_disp = c.replace("|", "\|")
                    lines.append(f"- {c_disp}")
            else:
                lines.append("_No columns detected or unreadable header._")
            lines.append("")

    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Create a Markdown report from the Excel produced by csv_cataloger.py"
    )
    p.add_argument("excel", type=Path, help="Path to the Excel catalog file (e.g., csv_catalog.xlsx).")
    p.add_argument(
        "-o", "--output",
        type=Path,
        default=Path("csv_catalog.md"),
        help="Output Markdown file path (default: ./csv_catalog.md)"
    )
    p.add_argument(
        "--no-table",
        action="store_true",
        help="Exclude the overview table section."
    )
    p.add_argument(
        "--no-details",
        action="store_true",
        help="Exclude the per-file detailed section."
    )
    p.add_argument(
        "-v", "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v for INFO, -vv for DEBUG)."
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    setup_logging(args.verbose)

    if not args.excel.exists():
        logging.error("Excel file does not exist: %s", args.excel)
        raise SystemExit(1)

    logging.info("Reading Excel: %s", args.excel)
    df = pd.read_excel(args.excel)

    logging.info("Rendering Markdown...")
    md = dataframe_to_markdown(
        df,
        include_table=not args.no_table,
        include_details=not args.no_details,
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(md, encoding="utf-8")
    logging.info("Markdown written to %s", args.output.resolve())


if __name__ == "__main__":
    main()
