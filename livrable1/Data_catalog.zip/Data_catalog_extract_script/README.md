# 📘 CSV Cataloger & Markdown Report Generator

Ce projet contient deux scripts Python complémentaires permettant de **recenser automatiquement les fichiers CSV d’un dossier**, d’**analyser leurs colonnes**, puis de **générer un rapport Excel et Markdown**.

---

## 🚀 Fonctionnalité

### 🧩 Script 1 — `csv_cataloger.py`
Analyse récursivement un dossier pour :
- Trouver tous les fichiers **`.csv`**, y compris dans les sous-dossiers.
- Lire uniquement l’en-tête pour détecter les **colonnes disponibles**.
- Produire un **fichier Excel (.xlsx)** contenant :
  - Le **nom du fichier**
  - Les **colonnes** détectées (séparées par `;`)
  - Le **chemin relatif** au dossier source

---

### 📝 Script 2 — `csv_catalog_to_md.py`
Lit le fichier Excel généré par le premier script et crée un **rapport Markdown (.md)** clair et lisible, avec :
- Un résumé général du nombre de fichiers CSV trouvés.
- Un tableau synthétique listant tous les fichiers, leurs chemins et le nombre de colonnes.
- Une section détaillée pour chaque fichier listant les colonnes disponibles.

---

## ⚙️ Installation

### Prérequis
Assure-toi d’avoir Python 3.8+ et les bibliothèques suivantes :
```bash
pip install pandas openpyxl
```

---

## 🧠 Utilisation

### 1️⃣ Scanner un dossier de CSV
```bash
python csv_cataloger.py /chemin/vers/le/dossier
```

#### Options
| Option | Description |
|--------|--------------|
| `-o`, `--output` | Spécifie le fichier Excel de sortie (par défaut `csv_catalog.xlsx`) |
| `-v`, `--verbose` | Active les logs détaillés (`-v` pour INFO, `-vv` pour DEBUG) |
| `--encodings` | Liste des encodages à tester si UTF-8 échoue (ex: `utf-8-sig cp1252 latin1`) |

#### Exemple
```bash
python csv_cataloger.py ./data -o ./reports/csv_catalog.xlsx -v
```

➡️ Produit un fichier **`csv_catalog.xlsx`** contenant :
| file_name | columns | relative_path |
|------------|----------|----------------|
| clients.csv | id; name; email | data/clients.csv |
| ventes.csv  | date; produit; montant | data/sales/ventes.csv |

---

### 2️⃣ Générer un rapport Markdown
```bash
python csv_catalog_to_md.py /chemin/vers/csv_catalog.xlsx
```

#### Options
| Option | Description |
|--------|--------------|
| `-o`, `--output` | Spécifie le fichier Markdown de sortie (par défaut `csv_catalog.md`) |
| `--no-table` | Exclut le tableau récapitulatif |
| `--no-details` | Exclut la section détaillée |
| `-v`, `--verbose` | Active les logs détaillés |

#### Exemple
```bash
python csv_catalog_to_md.py ./reports/csv_catalog.xlsx -o ./reports/catalogue.md
```

➡️ Produit un fichier **`csv_catalog.md`** du type :

```markdown
# CSV Catalog Report

_Generated on: 2025-10-09 15:22_

Total CSV files: **2**

## Overview

| File | Relative Path | Columns Count |
|------|----------------|---------------:|
| clients.csv | `data/clients.csv` | 3 |
| ventes.csv  | `data/sales/ventes.csv` | 3 |

## Details

### clients.csv
**Relative path:** `data/clients.csv`

**Columns:**
- id
- name
- email

### ventes.csv
**Relative path:** `data/sales/ventes.csv`

**Columns:**
- date
- produit
- montant
```

---

## 🧩 Organisation des fichiers

```
project/
├── csv_cataloger.py           # Script principal : scan des CSV et export Excel
├── csv_catalog_to_md.py       # Script complémentaire : conversion Excel → Markdown
├── data/                      # Exemple de dossier source
│   ├── clients.csv
│   └── sales/
│       └── ventes.csv
└── reports/
    ├── csv_catalog.xlsx
    └── csv_catalog.md
```

---

## 🛠️ Notes techniques
- Les colonnes sont lues sans charger tout le CSV (`nrows=0`), ce qui rend le script rapide même pour de gros fichiers.
- Les chemins sont relatifs au dossier source, formatés avec `/`.
- Le script gère plusieurs encodages (`utf-8`, `utf-8-sig`, `cp1252`, `latin1` par défaut).
- Le Markdown est généré en UTF-8 avec des caractères spéciaux correctement échappés (`|` dans les noms de colonnes).

---

## 🧾 Licence
Ce projet est librement réutilisable et modifiable à des fins personnelles ou professionnelles.  
Crédit : *Script généré par ChatGPT (GPT-5)*
