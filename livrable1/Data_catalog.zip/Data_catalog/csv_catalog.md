# CSV Catalog Report

_Generated on: 2025-10-09 11:15_

Total CSV files: **32**

## Overview

| File | Relative Path | Columns Count |
|---|---|---:|
| deces.csv | `DECES EN FRANCE/deces.csv` | 10 |
| activite_professionnel_sante.csv | `Etablissement de SANTE/activite_professionnel_sante.csv` | 3 |
| etablissement_sante.csv | `Etablissement de SANTE/etablissement_sante.csv` | 24 |
| professionnel_sante.csv | `Etablissement de SANTE/professionnel_sante.csv` | 9 |
| Hospitalisations.csv | `Hospitalisation/Hospitalisations.csv` | 7 |
| DPA_SSR_recueil2014_donnee2013_table_es.csv | `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_es.csv` | 21 |
| DPA_SSR_recueil2014_donnee2013_table_lexique.csv | `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_lexique.csv` | 2 |
| DPA_SSR_recueil2014_donnee2013_table_participant.csv | `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_participant.csv` | 6 |
| RCP_MCO_recueil2014_donnee2013_table_es.csv | `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_es.csv` | 9 |
| RCP_MCO_recueil2014_donnee2013_table_lexique.csv | `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_lexique.csv` | 2 |
| RCP_MCO_recueil2014_donnee2013_table_participant.csv | `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_participant.csv` | 6 |
| hpp_mco_recueil2015_donnee2014_lexique.csv | `Satisfaction/2015/hpp_mco_recueil2015_donnee2014_lexique.csv` | 2 |
| hpp_mco_recueil2015_donnee2014_tables_es.csv | `Satisfaction/2015/hpp_mco_recueil2015_donnee2014_tables_es.csv` | 18 |
| idm_mco_recueil2015_donnee2014_tables_es.csv | `Satisfaction/2015/idm_mco_recueil2015_donnee2014_tables_es.csv` | 14 |
| dan_mco_recueil2016_donnee2015_donnees.csv | `Satisfaction/2016/dan_mco_recueil2016_donnee2015_donnees.csv` | 17 |
| dan_mco_recueil2016_donnee2015_lexique.csv | `Satisfaction/2016/dan_mco_recueil2016_donnee2015_lexique.csv` | 2 |
| dpa_had_recueil2016_donnee2015_donnees.csv | `Satisfaction/2016/dpa_had_recueil2016_donnee2015_donnees.csv` | 32 |
| dpa_had_recueil2016_donnee2015_lexique.csv | `Satisfaction/2016/dpa_had_recueil2016_donnee2015_lexique.csv` | 2 |
| dpa-ssr-recueil2018-donnee2017-donnees.csv | `Satisfaction/2017-2018/dpa-ssr-recueil2018-donnee2017-donnees.csv` | 19 |
| dpa-ssr-recueil2018-donnee2017-lexique.csv | `Satisfaction/2017-2018/dpa-ssr-recueil2018-donnee2017-lexique.csv` | 2 |
| ete-ortho-ipaqss-2017-2018-donnees.csv | `Satisfaction/2017-2018/ete-ortho-ipaqss-2017-2018-donnees.csv` | 8 |
| ete-ortho-ipaqss-2017-2018-lexique.csv | `Satisfaction/2017-2018/ete-ortho-ipaqss-2017-2018-lexique.csv` | 2 |
| rcp-mco-recueil2018-donnee2017-donnees.csv | `Satisfaction/2017-2018/rcp-mco-recueil2018-donnee2017-donnees.csv` | 12 |
| rcp-mco-recueil2018-donnee2017-lexique.csv | `Satisfaction/2017-2018/rcp-mco-recueil2018-donnee2017-lexique.csv` | 2 |
| lexique-esatis48h-mco-open-data-2019.csv | `Satisfaction/2019/lexique-esatis48h-mco-open-data-2019.csv` | 2 |
| lexique-esatisca-mco-open-data-2019.csv | `Satisfaction/2019/lexique-esatisca-mco-open-data-2019.csv` | 2 |
| lexique-iqss-open-data-2019.csv | `Satisfaction/2019/lexique-iqss-open-data-2019.csv` | 2 |
| resultats-esatis48h-mco-open-data-2019.csv | `Satisfaction/2019/resultats-esatis48h-mco-open-data-2019.csv` | 25 |
| resultats-esatisca-mco-open-data-2019.csv | `Satisfaction/2019/resultats-esatisca-mco-open-data-2019.csv` | 23 |
| resultats-iqss-open-data-2019.csv | `Satisfaction/2019/resultats-iqss-open-data-2019.csv` | 49 |
| ESATIS48H_MCO_recueil2017_donnees.csv | `Satisfaction/ESATIS48H_MCO_recueil2017_donnees.csv` | 23 |
| ESATIS48H_MCO_recueil2017_lexique.csv | `Satisfaction/ESATIS48H_MCO_recueil2017_lexique.csv` | 2 |

## Details

### deces.csv

**Relative path:** `DECES EN FRANCE/deces.csv`

**Columns:**
- nom
- prenom
- sexe
- date_naissance
- code_lieu_naissance
- lieu_naissance
- pays_naissance
- date_deces
- code_lieu_deces
- numero_acte_deces

### activite_professionnel_sante.csv

**Relative path:** `Etablissement de SANTE/activite_professionnel_sante.csv`

**Columns:**
- identifiant
- identifiant_organisation
- mode_exercice

### etablissement_sante.csv

**Relative path:** `Etablissement de SANTE/etablissement_sante.csv`

**Columns:**
- adresse
- cedex
- code_commune
- code_postal
- commune
- complement_destinataire
- complement_point_geographique
- email
- enseigne_commerciale_site
- finess_etablissement_juridique
- finess_site
- identifiant_organisation
- indice_repetition_voie
- mention_distribution
- numero_voie
- pays
- raison_sociale_site
- siren_site
- siret_site
- telecopie
- telephone
- telephone_2
- type_voie
- voie

### professionnel_sante.csv

**Relative path:** `Etablissement de SANTE/professionnel_sante.csv`

**Columns:**
- identifiant
- civilite
- categorie_professionnelle
- nom
- prenom
- commune
- profession
- specialite
- type_identifiant

### Hospitalisations.csv

**Relative path:** `Hospitalisation/Hospitalisations.csv`

**Columns:**
- Num_Hospitalisation
- Id_patient
- identifiant_organisation
- Code_diagnostic
- Suite_diagnostic_consultation
- Date_Entree
- Jour_Hospitalisation

### DPA_SSR_recueil2014_donnee2013_table_es.csv

**Relative path:** `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_es.csv`

**Columns:**
- raison_sociale
- libelle_region
- cat
- finess
- Sources
- tdp_c_den_etbt
- tdp_c_etbt
- tdp_c_icbas_etbt
- tdp_c_ichaut_etbt
- dec_c_den_etbt
- dec_c_etbt
- dec_c_icbas_etbt
- dec_c_ichaut_etbt
- trd_c_den_etbt
- trd_c_etbt
- trd_c_icbas_etbt
- trd_c_ichaut_etbt
- dtn1_c1_den_etbt
- dtn1_c1_etbt
- dtn1_c1_icbas_etbt
- dtn1_c1_ichaut_etbt

### DPA_SSR_recueil2014_donnee2013_table_lexique.csv

**Relative path:** `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_lexique.csv`

**Columns:**
- NAME
- label

### DPA_SSR_recueil2014_donnee2013_table_participant.csv

**Relative path:** `Satisfaction/2014/DPA_SSR_recueil2014_donnee2013_table_participant.csv`

**Columns:**
- sources
- finess
- raison_sociale
- libelle_region
- cat
- repondant

### RCP_MCO_recueil2014_donnee2013_table_es.csv

**Relative path:** `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_es.csv`

**Columns:**
- Raison_sociale
- Libelle_region
- cat
- finess
- Sources
- rcp2_c2_den_etbt
- rcp2_c2_etbt
- rcp2_c2_icbas_etbt
- rcp2_c2_ichaut_etbt

### RCP_MCO_recueil2014_donnee2013_table_lexique.csv

**Relative path:** `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_lexique.csv`

**Columns:**
- NAME
- label

### RCP_MCO_recueil2014_donnee2013_table_participant.csv

**Relative path:** `Satisfaction/2014/RCP_MCO_recueil2014_donnee2013_table_participant.csv`

**Columns:**
- Sources
- Finess
- Raison_sociale
- Libelle_region
- cat
- repondant

### hpp_mco_recueil2015_donnee2014_lexique.csv

**Relative path:** `Satisfaction/2015/hpp_mco_recueil2015_donnee2014_lexique.csv`

**Columns:**
- NAME
- LABEL

### hpp_mco_recueil2015_donnee2014_tables_es.csv

**Relative path:** `Satisfaction/2015/hpp_mco_recueil2015_donnee2014_tables_es.csv`

**Columns:**
- Sources
- finess
- raison_sociale
- lib_reg
- code_reg
- cat
- del1_c1_den_etbt
- del1_c1_etbt
- del1_c1_icbas_etbt
- del1_c1_ichaut_etbt
- peci_hppi_c_den_etbt
- peci_hppi_c_etbt
- peci_hppi_c_icbas_etbt
- peci_hppi_c_ichaut_etbt
- surmin_c_den_etbt
- surmin_c_etbt
- surmin_c_icbas_etbt
- surmin_c_ichaut_etbt

### idm_mco_recueil2015_donnee2014_tables_es.csv

**Relative path:** `Satisfaction/2015/idm_mco_recueil2015_donnee2014_tables_es.csv`

**Columns:**
- Sources
- finess
- raison_sociale
- lib_reg
- code_reg
- cat
- basi_c_den_etbt
- basi_c_etbt
- basi_c_icbas_etbt
- basi_c_ichaut_etbt
- hyg_c_den_etbt
- hyg_c_etbt
- hyg_c_icbas_etbt
- hyg_c_ichaut_etbt

### dan_mco_recueil2016_donnee2015_donnees.csv

**Relative path:** `Satisfaction/2016/dan_mco_recueil2016_donnee2015_donnees.csv`

**Columns:**
- finess
- Sources
- lib_reg
- code_reg
- raison_sociale
- lib_cat
- repondant
- resultat_tda
- resultat_trd
- tda_c_etbt
- tda_c_ichaut_etbt
- tda_c_icbas_etbt
- tda_c_den_etbt
- trd_c_etbt
- trd_c_ichaut_etbt
- trd_c_icbas_etbt
- trd_c_den_etbt

### dan_mco_recueil2016_donnee2015_lexique.csv

**Relative path:** `Satisfaction/2016/dan_mco_recueil2016_donnee2015_lexique.csv`

**Columns:**
- NAME
- LABEL

### dpa_had_recueil2016_donnee2015_donnees.csv

**Relative path:** `Satisfaction/2016/dpa_had_recueil2016_donnee2015_donnees.csv`

**Columns:**
- finess
- Sources
- lib_reg
- code_reg
- raison_sociale
- lib_cat
- repondant
- resultat_dec
- resultat_dtn
- resultat_tdp
- resultat_trd
- resultat_tre
- dec_c_etbt
- dec_c_ichaut_etbt
- dec_c_icbas_etbt
- dec_c_den_etbt
- dtn_c_etbt
- dtn_c_ichaut_etbt
- dtn_c_icbas_etbt
- dtn_c_den_etbt
- tdp_c_etbt
- tdp_c_ichaut_etbt
- tdp_c_icbas_etbt
- tdp_c_den_etbt
- trd_c_etbt
- trd_c_ichaut_etbt
- trd_c_icbas_etbt
- trd_c_den_etbt
- tre_c_etbt
- tre_c_ichaut_etbt
- tre_c_icbas_etbt
- tre_c_den_etbt

### dpa_had_recueil2016_donnee2015_lexique.csv

**Relative path:** `Satisfaction/2016/dpa_had_recueil2016_donnee2015_lexique.csv`

**Columns:**
- NAME
- LABEL

### dpa-ssr-recueil2018-donnee2017-donnees.csv

**Relative path:** `Satisfaction/2017-2018/dpa-ssr-recueil2018-donnee2017-donnees.csv`

**Columns:**
- finess
- Raison_sociale
- Enquete_obligatoire
- Participation
- Resultat_doc
- doc_c_den_etbt
- doc_c_etbt
- doc_c_icbas_etbt
- doc_c_ichaut_etbt
- doc_c_pos_seuil_etbt
- doc_c_pos_evol_etbt
- Resultat_dtn
- dtn2_c2_den_etbt
- dtn2_c2_etbt
- dtn2_c2_icbas_etbt
- dtn2_c2_ichaut_etbt
- dtn2_c2_pos_seuil_etbt
- dtn2_c2_pos_evol_etbt
- Lib_reg

### dpa-ssr-recueil2018-donnee2017-lexique.csv

**Relative path:** `Satisfaction/2017-2018/dpa-ssr-recueil2018-donnee2017-lexique.csv`

**Columns:**
- NAME
- LABEL

### ete-ortho-ipaqss-2017-2018-donnees.csv

**Relative path:** `Satisfaction/2017-2018/ete-ortho-ipaqss-2017-2018-donnees.csv`

**Columns:**
- finess
- rs
- region
- ete_ortho_cible_etbt
- ete_ortho_obs_etbt
- ete_ortho_att_etbt
- ete_ortho_etbt
- ete_ortho_pos_seuil_etbt

### ete-ortho-ipaqss-2017-2018-lexique.csv

**Relative path:** `Satisfaction/2017-2018/ete-ortho-ipaqss-2017-2018-lexique.csv`

**Columns:**
- NAME
- LABEL

### rcp-mco-recueil2018-donnee2017-donnees.csv

**Relative path:** `Satisfaction/2017-2018/rcp-mco-recueil2018-donnee2017-donnees.csv`

**Columns:**
- finess
- Raison_sociale
- Enquete_obligatoire
- Participation
- Resultat_rcp2
- rcp2_c2_den_etbt
- rcp2_c2_etbt
- rcp2_c2_icbas_etbt
- rcp2_c2_ichaut_etbt
- rcp2_c2_pos_seuil_etbt
- rcp2_c2_pos_evol_etbt
- Lib_reg

### rcp-mco-recueil2018-donnee2017-lexique.csv

**Relative path:** `Satisfaction/2017-2018/rcp-mco-recueil2018-donnee2017-lexique.csv`

**Columns:**
- NAME
- LABEL

### lexique-esatis48h-mco-open-data-2019.csv

**Relative path:** `Satisfaction/2019/lexique-esatis48h-mco-open-data-2019.csv`

**Columns:**
- Nom de la variable
- Libellé de la variable

### lexique-esatisca-mco-open-data-2019.csv

**Relative path:** `Satisfaction/2019/lexique-esatisca-mco-open-data-2019.csv`

**Columns:**
- Nom de la variable
- Libellé de la variable

### lexique-iqss-open-data-2019.csv

**Relative path:** `Satisfaction/2019/lexique-iqss-open-data-2019.csv`

**Columns:**
- NAME
- LABEL

### resultats-esatis48h-mco-open-data-2019.csv

**Relative path:** `Satisfaction/2019/resultats-esatis48h-mco-open-data-2019.csv`

**Columns:**
- finess
- rs_finess
- finess_geo
- rs_finess_geo
- region
- participation
- Depot
- nb_rep_score_all_rea_ajust
- score_all_rea_ajust
- classement
- evolution
- nb_rep_score_accueil_rea_ajust
- score_accueil_rea_ajust
- nb_rep_score_PECinf_rea_ajust
- score_PECinf_rea_ajust
- nb_rep_score_PECmed_rea_ajust
- score_PECmed_rea_ajust
- nb_rep_score_chambre_rea_ajust
- score_chambre_rea_ajust
- nb_rep_score_repas_rea_ajust
- score_repas_rea_ajust
- nb_rep_score_sortie_rea_ajust
- score_sortie_rea_ajust
- taux_reco_brut
- nb_reco_brut

### resultats-esatisca-mco-open-data-2019.csv

**Relative path:** `Satisfaction/2019/resultats-esatisca-mco-open-data-2019.csv`

**Columns:**
- finess
- rs_finess
- finess_geo
- rs_finess_geo
- region
- participation
- Depot
- nb_rep_score_all_ajust
- score_all_ajust
- classement
- evolution
- score_AVH_ajust
- nb_rep_score_AVH_ajust
- score_ACC_ajust
- nb_rep_score_ACC_ajust
- score_PEC_ajust
- nb_rep_score_PEC_ajust
- score_CER_ajust
- nb_rep_score_CER_ajust
- score_OVS_ajust
- nb_rep_score_OVS_ajust
- taux_reco_brut
- nb_reco_brut

### resultats-iqss-open-data-2019.csv

**Relative path:** `Satisfaction/2019/resultats-iqss-open-data-2019.csv`

**Columns:**
- finess
- finess_pmsi
- nom_ES
- region
- type
- obligatoire_icsha_v3_mhs
- classe_ias_icsha_v3_mhs
- res_ias_icsha_v3_mhs
- evol_ias_icsha_v3_mhs
- obligatoire_icsha_v3_psy
- classe_ias_icsha_v3_psy
- res_ias_icsha_v3_psy
- evol_ias_icsha_v3_psy
- obligatoire_dpa_had
- classe_DPA_dtn_HAD
- res_dpa_dtn_had
- evol_dpa_dtn_had
- classe_DPA_tre_HAD
- res_dpa_tre_had
- evol_dpa_tre_had
- classe_DPA_coord_HAD
- res_dpa_coord_had
- evol_dpa_coord_had
- classe_DPA_tdp_v3_HAD
- res_dpa_tdp_v3_had
- evol_dpa_tdp_v3_had
- obligatoire_dpa_mco
- classe_DPA_qls_v2_MCO
- res_dpa_qls_v2_mco
- evol_dpa_qls_v2_mco
- classe_DPA_pcd_MCO
- res_dpa_pcd_mco
- evol_dpa_pcd_mco
- obligatoire_dpa_ssr
- classe_DPA_qls_SSR
- res_dpa_qls_ssr
- evol_dpa_qls_ssr
- classe_DPA_pcd_SSR
- res_dpa_pcd_ssr
- evol_dpa_pcd_ssr
- classe_DPA_pspv_SSR
- res_dpa_pspv_ssr
- evol_dpa_pspv_ssr
- obligatoire_ca_mco
- classe_CA_qls_v2_MCO
- res_ca_qls_v2_mco
- evol_ca_qls_v2_mco
- ete_ortho_ratio_oe
- ete_ortho_alerte_supe

### ESATIS48H_MCO_recueil2017_donnees.csv

**Relative path:** `Satisfaction/ESATIS48H_MCO_recueil2017_donnees.csv`

**Columns:**
- finess
- rs_finess
- finess_geo
- rs_finess_geo
- region
- participation
- Depot
- nb_rep_score_all_rea_ajust
- score_all_rea_ajust
- classement
- evolution
- nb_rep_score_accueil_rea_ajust
- score_accueil_rea_ajust
- nb_rep_score_PECinf_rea_ajust
- score_PECinf_rea_ajust
- nb_rep_score_PECmed_rea_ajust
- score_PECmed_rea_ajust
- nb_rep_score_chambre_rea_ajust
- score_chambre_rea_ajust
- nb_rep_score_repas_rea_ajust
- score_repas_rea_ajust
- nb_rep_score_sortie_rea_ajust
- score_sortie_rea_ajust

### ESATIS48H_MCO_recueil2017_lexique.csv

**Relative path:** `Satisfaction/ESATIS48H_MCO_recueil2017_lexique.csv`

**Columns:**
- NAME
- LABEL

